
-- this is the file to put all your custom logic functions into.
-- if you dont want to use the json based logic you can switch to a graph-based logic method.
-- the needed functions for that are in `/scripts/logic/graph_logic/logic_main.lua`.



-- function <name> (<parameters if needed>)
--     <actual code>
--     <indentations are just for readability>
-- end
--


-- Globals for Schedule I slot data (persistent after connection)
local randomize_customers = nil
local randomize_dealers = nil
local randomize_suppliers = nil
local randomize_level_unlocks = nil
local randomize_business_properties = nil
local randomize_cartel_influence = nil
local recipe_checks_count = 0
local cash_for_trash_count = 0

-- Clear handler: captures slot data when connected
Archipelago:AddClearHandler("schedule_i_slot_data_init", function(slot_data)
    print("ClearHandler fired! Slot data received.")

    -- Helper to safely read bool from top-level or options
    local function get_bool(val, fallback)
        if val == nil and slot_data.options then
            val = slot_data.options[fallback]
        end
        return (val == true or val == 1)
    end

    randomize_customers           = get_bool(slot_data.randomize_customers,          "randomize_customers")
    randomize_dealers             = get_bool(slot_data.randomize_dealers,            "randomize_dealers")
    randomize_suppliers           = get_bool(slot_data.randomize_suppliers,          "randomize_suppliers")
    randomize_level_unlocks       = get_bool(slot_data.randomize_level_unlocks,      "randomize_level_unlocks")
    randomize_business_properties = get_bool(slot_data.randomize_business_properties, "randomize_business_properties")
    randomize_cartel_influence    = get_bool(slot_data.randomize_cartel_influence,   "randomize_cartel_influence")

    -- Numbers (default 0 if missing)
    recipe_checks_count = tonumber(slot_data.recipe_checks) or 0
    cash_for_trash_count = tonumber(slot_data.cash_for_trash) or 0

    -- Optional debug prints (remove later if you want)
    print("randomize_customers: " .. tostring(randomize_customers))
    print("randomize_dealers: " .. tostring(randomize_dealers))
    print("randomize_suppliers: " .. tostring(randomize_suppliers))
    print("randomize_level_unlocks: " .. tostring(randomize_level_unlocks))
    print("randomize_business_properties: " .. tostring(randomize_business_properties))
    print("randomize_cartel_influence: " .. tostring(randomize_cartel_influence))
    print("recipe_checks: " .. recipe_checks_count)
    print("cash_for_trash: " .. cash_for_trash_count)

    Tracker:Update()
end)

-- ==================== BOOLEAN OPTION FUNCTIONS ====================

function hasRandomizeCustomers()           return randomize_customers           and 1 or 0 end
function hasNormalCustomers()              return (not randomize_customers)     and 1 or 0 end

function hasRandomizeDealers()             return randomize_dealers             and 1 or 0 end
function hasNormalDealers()                return (not randomize_dealers)       and 1 or 0 end

function hasRandomizeSuppliers()           return randomize_suppliers           and 1 or 0 end
function hasNormalSuppliers()              return (not randomize_suppliers)     and 1 or 0 end

function hasRandomLevels()                 return randomize_level_unlocks       and 1 or 0 end
function hasNormalLevels()                 return (not randomize_level_unlocks) and 1 or 0 end

function hasRandomBusiness()               return randomize_business_properties and 1 or 0 end
function hasNormalBusiness()               return (not randomize_business_properties) and 1 or 0 end

function hasRandomCartel()                 return randomize_cartel_influence    and 1 or 0 end
function hasNormalCartel()                 return (not randomize_cartel_influence) and 1 or 0 end

-- ==================== NUMERIC THRESHOLD FUNCTIONS ====================

-- Use like: "$hasEnoughRecipes|8"  → true if recipe_checks >= 8
function hasEnoughRecipes(target)
    target = tonumber(target) or 0
    return (recipe_checks_count >= target) and 1 or 0
end

-- Use like: "$hasEnoughTrash|30"  → true if cash_for_trash >= 30
function hasEnoughTrash(target)
    target = tonumber(target) or 0
    return (cash_for_trash_count >= target) and 1 or 0
end